let i = 0;
while (i < 3) {
    alert( `number ${i}!` );
    i++;
}
const BIRTHDAY = '25.08.2004';
let age = BIRTHDAY;
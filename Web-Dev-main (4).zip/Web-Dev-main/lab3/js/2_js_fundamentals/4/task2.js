let planetEarth = "Earth";
let currentUser;
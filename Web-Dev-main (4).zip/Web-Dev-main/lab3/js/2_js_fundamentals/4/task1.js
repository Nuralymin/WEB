let admin, name;
name = "John";
admin = name;
alert(admin);
//The first variant:
if (!(age >= 14 && age <= 90))

//The second variant:
if (age < 14 || age > 90)
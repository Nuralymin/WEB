function copySorted(arr) {
    return arr.slice().sort();
}
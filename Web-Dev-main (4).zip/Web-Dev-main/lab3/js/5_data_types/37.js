let someDate = new Date(2012,2,20,3,12);
alert(someDate);
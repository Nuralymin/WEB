let i = 0;
while (i != 10) {
    i += 0.2;
} // it will be infinity cuz 10.0 != 10, and adding by fractional number will cause an inaccuracy

function ucFisrt(str) {
    let first = str.charAt(0).toUpperCase();
    return first + str.slice(1);
}
function sortByAge(arr) {
    arr.sort((a, b) => a.age - b.age);
}
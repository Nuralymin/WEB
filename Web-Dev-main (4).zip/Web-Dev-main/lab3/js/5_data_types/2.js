let a = +prompt("a", "");
let b = +prompt("b", "");

alert( a + b );
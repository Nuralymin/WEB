let str = "Hello";

str.test = 5;

alert(str.test); // it won't work, because str.test is not a function